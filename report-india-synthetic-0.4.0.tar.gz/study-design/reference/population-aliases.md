# Population aliases

## Cohort A

Index cases are also described as active pulmonary TB participants or index cases.

## Cohort B

Household contacts are also described as household contacts or contacts.

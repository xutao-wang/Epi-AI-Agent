# RePORT India Study Design

## Purpose

RePORT India is a prospective observational tuberculosis cohort study.

## Study populations

- **Index cases (Cohort A):** participants with active pulmonary tuberculosis who serve as the index cases for household-contact follow-up.
- **Household contacts (Cohort B):** household contacts enrolled in relation to a Cohort A index case, including contacts who later progress to active tuberculosis.

## Relationship

Each Cohort B participant is linked to an index case in Cohort A.

## Authority

This overview is authoritative for population interpretation, cohort selection, and schema-evidence interpretation. Retrieved design documents may add detail, but this overview controls when they conflict unless it explicitly delegates authority or identifies a superseding amendment.

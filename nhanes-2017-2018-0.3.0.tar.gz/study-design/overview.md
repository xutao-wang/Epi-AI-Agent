# NHANES 2017-2018

## Study identity and appropriate use

The National Health and Nutrition Examination Survey (NHANES) is a continuing, cross-sectional program conducted by the U.S. National Center for Health Statistics. This package contains selected public-use data from the 2017-2018 survey cycle. It is appropriate for questions about participant demographics, self-reported health conditions and behaviors, standardized physical examinations, and laboratory measurements in the United States.

This is participant-level health survey data. It is not a disease case-report registry, a grant or publication database, a longitudinal cohort, or a source for following the same respondents across survey cycles.

## Target population and sample design

NHANES is designed to represent the civilian, noninstitutionalized U.S. population. It uses a complex, multistage probability sample. Nationally representative estimation generally requires the appropriate NHANES sample weight together with the masked variance strata and primary sampling units in `DEMO_J`. The correct weight depends on the components and subsamples used in an analysis; the most restrictive applicable examination, laboratory, fasting, or other subsample weight controls.

The 2017-2018 cycle is one cross-sectional cycle. Eligibility, examination attendance, questionnaire routing, laboratory subsampling, and item nonresponse differ by component, so tables do not necessarily contain exactly the same respondents.

## Packaged data scope

The package contains 18 tables:

- Demographics: `DEMO_J`.
- Questionnaires: `DIQ_J`, `BPQ_J`, `MCQ_J`, `KIQ_U_J`, `SMQ_J`, `PAQ_J`, `ALQ_J`, and `RXQ_RX_J`.
- Examinations: `BMX_J` and `BPX_J`.
- Laboratory: `GHB_J`, `GLU_J`, `BIOPRO_J`, `ALB_CR_J`, `HDL_J`, `TCHOL_J`, and `TRIGLY_J`.

These tables cover age, sex, race and ethnicity, education, income and poverty measures, survey-design variables and weights; diabetes, hypertension, cardiovascular and other medical conditions; kidney and urinary conditions; smoking, physical activity, and alcohol; prescription medications; body measurements and measured blood pressure; glycated hemoglobin, fasting glucose, kidney and liver biomarkers, urine albumin and creatinine, and lipids.

## Linkage and row grain

`SEQN` is the respondent sequence number and the within-cycle participant linkage key. Most packaged tables have at most one row per `SEQN`, but `RXQ_RX_J` is medication-level and can contain multiple prescription-drug rows per participant. A dataset plan must preserve that grain distinction and must not treat a medication row as a participant row.

Use `DEMO_J` as the usual source of demographic covariates, survey-design variables, and cycle-level weights, then join eligible component tables on `SEQN`. Confirm observed key coverage and relationship behavior before extraction. Missing component rows can reflect ineligibility, nonparticipation, subsampling, or nonresponse and should not automatically be interpreted as a negative clinical response.

All SQL extraction and joins must remain within this study package. Results from another installed study can be analyzed separately but are not SQL-joinable to NHANES participants.

## Routing guidance

Choose this study for requests that explicitly mention NHANES, the United States, the 2017-2018 survey cycle, national health examination data, measured biomarkers, HbA1c, blood pressure, body measurements, health questionnaires, prescription medications, or NHANES complex-survey weights.

Do not choose this study for tuberculosis case-report surveillance questions, India-specific case records, grant records, or questions whose requested population or period is incompatible with the 2017-2018 U.S. NHANES cycle. If a question only names a common concept such as smoking or diabetes and the intended population is unclear, compare the installed study overviews and ask the user for clarification when no study is clearly dominant.

## Documentation and limitations

Variable meanings, target populations, response codes, skip patterns, and codebook counts are carried in the reviewed annotation JSON paired with each table and are discoverable through the schema catalog. The original CDC XPT files are preserved as the source tabular data.

This package currently contains no publication-support corpus. Publication evidence retrieval is therefore unavailable for this study. The overview supplies study-selection and design context only; it does not replace the official NHANES analytic guidance, component documentation, or variable codebooks.
